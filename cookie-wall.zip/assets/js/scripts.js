jQuery("#readmore").click(function(){
	event.preventDefault();
    jQuery("#readmore_content").toggle();
});